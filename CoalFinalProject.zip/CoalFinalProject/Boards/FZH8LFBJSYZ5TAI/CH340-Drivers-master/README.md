# CH340-Drivers
CH340 Drivers for Hobby Components Products

####Microsoft Windows:
Windows drivers support 32 and 64 bit versions of the opperating system. These drivers will need to be installed whn using any of the Hobby Components products listed below.

####Linux drivers:
Most popular versions will include a sutable driver and so no additional installation is normally required.

###Supported products:


**Hobby Components Arduino Compatible Uno+ (HCARDU0100)**

![alt tag](http://hobbycomponents.com/images/forum/HCARDU0100_1_800_600.JPG)

http://hobbycomponents.com/boards/670-hobby-components-uno-plus


**Hobby Components Arduino Compatible Nano with CH340 (HCARDU0094)**

![alt tag](http://hobbycomponents.com/images/forum/HCARDU0094_800_600.JPG)

http://hobbycomponents.com/featured/98-arduino-compatible-nano-v30-with-free-usb-cable


**CH340 USB to TTL Serial Adaptor (HCMODU0076)**

![alt tag](http://hobbycomponents.com/images/forum/HCMODU0076_800_600.JPG)

http://hobbycomponents.com/home/586-ch340-usb-to-ttl-serial-adaptor
